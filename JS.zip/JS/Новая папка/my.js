var imgs;
var currentIndex=0;
function myFunc(){
	imgs=document.querySelectorAll('.wrapper img');
		for(var i=0;i<imgs.length;i++){
			imgs[i].className="not-visible";
		}
}

function nextClick(){
	imgs[currentIndex].className='not-visible';
		if(currentIndex==imgs.length-1){
			currentIndex=-1;
	imgs[++currentIndex].className='visible';	
		}
}	
	
	
function prevClick(){
	imgs[currentIndex].className='not-visible';
		if(currentIndex==0){
			currentIndex=imgs.length;
	imgs[--currentIndex].className='visible';
		}
}