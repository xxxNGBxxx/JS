	function Merge(array,low,mid,high)    //��������������� �������.
		{
			var tmp_array = new Array(high+1-low);
			var	h=low;
			var i=0;
			var k=0;
			var j = mid+1;
			
			while (h <= mid && j <= high )
			 { 
				if (array[h] <= array[j]){
					tmp_array[i]=array[h]; 
					h++; 
				}
			   else  {
				tmp_array[ i ]=array[j]; 
				j++; 
			   }
			   i++;
			 }
			if (h > mid){ 
				for (k = j; k <= high; k++){ 
					tmp_array[ i ]=array[k]; 
					i++; 
				} 
			}
			else   { 
				for (k = h; k <= mid; k++){
					tmp_array[ i ]=array[k]; 
					i++; 
				} 
			}    
			
			for (k=0; k<=high-low; k++)
				array[k+low]=tmp_array[k];
				
				
			return array;
		}
		
		 function merge_sort(array,low,high)
		 { 
			if (low < high)
			{ 
			  var mid = Math.floor((low+high)/2);
			  merge_sort(array, low, mid);
			  merge_sort(array, mid+1, high);
			  Merge(array, low, mid, high);
			}
		 }

		function mergeSort(array)      //������� ���������� ���������.
		{
			merge_sort(array, 0, array.length-1);
	
		}